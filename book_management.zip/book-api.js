const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path'); 

const app = express();
const port = 3000;

// Where we will keep books
let books = [];

// middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Add a new book
app.post('/book', (req, res) => {
    const book = req.body;
    console.log(book);
    books.push(book);
    res.send('Book is added to the database');
});

// Get all books or search books by title/author
app.get('/books', (req, res) => {
    const search = req.query.search ? req.query.search.toLowerCase() : '';

    if (search) {
        const filteredBooks = books.filter(book =>
            book.title.toLowerCase().includes(search) || book.author.toLowerCase().includes(search)
        );
        res.json(filteredBooks);
    } else {
        res.json(books);
    }
});

// Get a book by ISBN
app.get('/book/:isbn', (req, res) => {
    const isbn = req.params.isbn;
    const book = books.find(b => b.isbn === isbn);
    if (book) {
        res.json(book);
    } else {
        res.status(404).send('Book not found');
    }
});

// Delete a book
app.delete('/book/:isbn', (req, res) => {
    const isbn = req.params.isbn;
    books = books.filter(b => b.isbn !== isbn);
    res.send('Book is deleted');
});

// Edit a book
app.post('/book/:isbn', (req, res) => {
    const isbn = req.params.isbn;
    const newBook = req.body;
    for (let i = 0; i < books.length; i++) {
        if (books[i].isbn === isbn) {
            books[i] = newBook;
            return res.send('Book is edited');
        }
    }
    res.status(404).send('Book not found');
});

app.listen(port, () => console.log(`App listening on port ${port}!`));